# y_foreach

See [y_iterate](y_iterate.md)

